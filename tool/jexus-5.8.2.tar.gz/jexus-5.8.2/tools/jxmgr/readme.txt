这是Jexus web server的远程管理工具，项目地址：https://github.com/jexuswebserver/jxmgr

This is a remote administration tool for Jexus web server, Project URL: https://github.com/jexuswebserver/jxmgr
